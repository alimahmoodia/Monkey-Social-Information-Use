clc; clear all; close all;
files = dir ('*.txt');

for ses = 1:size(files,1)
    output =  str2num(fileread(files(ses).name));
    output(output(:,15)==10,:) = [] ;
    y = output(:,15)- 1;
    
    face = output(1:150,23);
    for t = 1 : 150
        if output(t,3) == 12 | output(t,3) == 14
            obj(t,1) = 2;
        else
            obj(t,1) = 1;
        end
    end
    
    [temp,dev] = glmfit([zscore(obj(1:50)) zscore(face(1:50))],y(1:50),'binomial','link','logit')
    
    [temp,dev] = glmfit([zscore(obj(51:100)) zscore(face(51:100))],y(51:100),'binomial','link','logit')
    
    [temp,dev] = glmfit([zscore(obj(101:150)) zscore(face(101:150))],y(101:150),'binomial','link','logit')
    sum(output(:,15)==output(:,16))
    
    %% RT
    mean(output(:,14))

end