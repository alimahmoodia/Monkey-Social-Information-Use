clc; clear all; close all
baseDir = '/Users/alimahmoodi/Documents/MATLAB/Monkey_SocialInfluence';
animals = {'Tim','Voodoo','Warwick'};
betasf6s9 = [];
betasf9s6 = [];
betasf9s9 = [];
mat_f9s9=[]; mat_f6s9=[];mat_f9s6=[];
Trig_time = findPulseTime;

for animal = 1:3
    animalDir = [baseDir,filesep,animals{animal},filesep,'scan'];
    files = dir([animalDir,filesep,'*.txt']);
    rt_all=[];
    for session = 1 : size(files,1)
        output = str2num(fileread([animalDir,filesep,files(session).name]));
        NoResp_trials = find(output(:,15)==10);
        output(NoResp_trials,:) = []; %% in the previous line we identified non reponse trials and removed them in the current trial.
        rt_all = [rt_all;output(:,14)];
        trs = find(output(:,23)>2 & mod(output(:,23),3) == 1); %% correct your mess here
        output(trs,23) = 1;
        clear trs
        trs = find(output(:,23)>2 & mod(output(:,23),3) == 2); %% correct your mess here
        output(trs,23) = 2;
        clear trs
        %% face reliability
        face_correctness = output(:,16) == output(:,23);
        face_prob(1:50,:)  = sum(face_correctness(1:50))*.02;
        face_prob(51:100,:)  = sum(face_correctness(51:100))*.02;
        face_prob(101:150,:)  = sum(face_correctness(101:150))*.02;
        face_dir = -2.*output(:,23)+3;
        face_rel = (2.*face_prob-1).*face_dir;
        %% do the same for the objects
        obj = (output(:,3) - output(:,2)).*.5 + 1.5;
        obj_correctness = obj == output(:,16);
        obj_prob(1:50,:)  = sum(obj_correctness(1:50))*.02;
        obj_prob(51:100,:)  = sum(obj_correctness(51:100))*.02;
        obj_prob(101:150,:)  = sum(obj_correctness(101:150))*.02;
        obj_dir = -2.*obj+3;
        obj_rel = (2.*obj_prob-1).*obj_dir;
        
        choice = output(:,15)-1;
        temp_tr = find(face_prob == .92);
        face_prob(temp_tr) = .9;
        temp_tr = find(obj_prob == .62);
        obj_prob(temp_tr) = .6;
        
        
        trials = find(obj_prob == .9 & face_prob == .6);
        %[betas,dev] = glmfit([(-obj_rel(trials,:)) (-face_rel(trials,:)) (-obj_rel(trials,:)).*zscore(-face_rel(trials,:))],choice(trials,:),'binomial','link','logit');
        %betasf6s9(end+1,1:4) = betas';
        mat_f6s9 = [mat_f6s9; (choice(trials,:)) (-obj_rel(trials,:)) (-face_rel(trials,:)) ((animal-1)*16+session)*ones(50,1)];
        clear trials
        trials = find(obj_prob == .6 & face_prob == .9);
        %[betas,dev] = glmfit([zscore(-obj_rel(trials,:)) zscore(-face_rel(trials,:)) zscore(-obj_rel(trials,:)).*zscore(-face_rel(trials,:))],choice(trials,:),'binomial','link','logit');
        %betasf9s6(end+1,1:4) = betas';
        mat_f9s6 = [mat_f9s6; (choice(trials,:)) (-obj_rel(trials,:)) (-face_rel(trials,:)) ((animal-1)*16+session)*ones(50,1)];
        clear trials
        trials = find(obj_prob == .9 & face_prob == .9);
        %[betas,dev] = glmfit([zscore(-obj_rel(trials,:)) zscore(-face_rel(trials,:)) zscore(-obj_rel(trials,:)).*zscore(-face_rel(trials,:))],choice(trials,:),'binomial','link','logit');
        %betasf9s9(end+1,1:4) = betas';
        mat_f9s9 = [mat_f9s9; (choice(trials,:)) (-obj_rel(trials,:)) (-face_rel(trials,:)) ((animal-1)*16+session)*ones(50,1)];
    end
    length(find(rt_all>2500))
    rt_animal{animal} = rt_all;
end

%% to change to a different condition, just change mat_f9s6 (this is the face condition) to another one
tbl = table((mat_f9s6(:,1)),(mat_f9s6(:,2)),(mat_f9s6(:,3)),mat_f9s6(:,4), 'VariableNames',{'choice','obj_rel','face_rel','s'});
tbl = table(zscore(mat_f9s9(:,1)),zscore(mat_f9s9(:,2)),zscore(mat_f9s9(:,3)),mat_f9s9(:,4), 'VariableNames',{'choice','obj_rel','face_rel','s'});
lme = fitlme(tbl,'choice~obj_rel*face_rel+(1+face_rel+obj_rel|s)','CheckHessian',true,'FitMethod','REML','DummyVarCoding','effects')
anova(lme,'DFMethod','Satterthwaite')


%%

CI_ic = coefCI(lme);
CI_c = coefCI(lme);
figure


%%
coef_ch = [lme.Coefficients.Estimate(2) lme.Coefficients.Estimate(3)];
CIlow=[CI_c(2,1) CI_ic(3,1)];
CIhigh = [CI_c(2,2) CI_ic(3,2)];
x =[.5 1];

%%
b= bar(x,coef_ch,.8,'FaceColor',[55, 153, 75]./255,'EdgeColor','none','LineWidth',1.5);
b.FaceColor = 'flat';
b.CData(2,:) = [153, 31, 133]./255;
%b.CData(3,:) = [211, 233, 22]./255;
hold on
for coef = 1 : 2
    y = CIlow(1,coef):.01:CIhigh(1,coef);
    if coef == 1
        h = plot(x(coef) + zeros(length(y)),y,'color',[55, 153, 75]./255);
    elseif coef == 2
        h = plot(x(coef) + zeros(length(y)),y,'color',[153, 31, 133]./255);
%     elseif coef == 3
%         h = plot(x(coef) + zeros(length(y)),y,'color',[211, 233, 22]./255);
    end
    h(1).LineWidth = 2;
    
end


ax= gca;
ax.XTick =[];
ax.XAxis.Color = [0 0 0];
ax.YAxis.Color = 'black';
set(gca,'linewidth',1.25)
box off
%ylabel('effect on choice ')
ax.XTick = [.5 1];
ax.XTickLabel = {'',''};
set(gca,'fontsize',26)
%xlabel('coefficient')
ylim([0 1])
xlim([0 3])

