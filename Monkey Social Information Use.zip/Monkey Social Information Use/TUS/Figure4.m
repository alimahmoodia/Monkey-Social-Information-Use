clc; clear all; close all;
%% by changing all mainobj to mainf or vice versa you can plot object or face conditions
        %colours = [207 143 48; 159 48 207;48 146 207]./256;
        
        %colours = [24 63 231; 24 63 231;24 63 231]./256;  %%% face
        
         colours = [69 186 75; 69 186 75;69 186 75]./256;   %%% object
        
for areas = 1 : 3
    
    if areas == 1
        load fpc_sham_mainf_incon
    elseif areas == 2
        load sts_sham_mainf_incon
    else
        load vis_sham_mainf_incon
    end
tbl = table(mat(:,1),(mat(:,2)),(mat(:,3)), -mat(:,4),mat(:,5), 'VariableNames',{'ch','obj','face','area','s'});
    lme = fitlme(tbl,'ch~ area','CheckHessian',true,'FitMethod','REML','DummyVarCoding','effects')
    
    anova(lme,'DFMethod','Satterthwaite')
    
    %%
    CI_c = coefCI(lme);
 
 
coef_ch = [lme.Coefficients.Estimate(2)];
CIlow=CI_c(2,1);
CIhigh = CI_c(2,2);
y = CIlow:.01:CIhigh;
x =[areas*2-1];
b= bar(x,coef_ch,.7,'FaceColor',colours(areas,:),'EdgeColor','none','LineWidth',1.5);
b.FaceColor = 'flat';

hold on

        h = plot(areas*2-1 + zeros(length(y)),y,'color',colours(areas,:));
  
    h(1).LineWidth = 2;


ax= gca;
ax.XTick =[];
ax.XAxis.Color = [0 0 0];
ax.YAxis.Color = 'black';
set(gca,'linewidth',1.25)
box off
%ylabel('effect on accuracy ')
ax.XTick = [1 2 3];
ax.XTickLabel = {'', '', ''};
set(gca,'fontsize',26)
%xlabel('coefficient') 
ylim([-.1 .1])
    
end


        %colours = [0 188 255;0 188 255;0 188 255]./256; %%% face
         colours = [176 240 137;176 240 137;176 240 137]./256;   %%% object
%         colours(1,1) = 256;
%         colours(2,3) = colours(1,1);
%         colours(3,3) = colours(1,1);
for areas = 1 : 3
    
    if areas == 1
        load fpc_sham_mainf_con
    elseif areas == 2
        load sts_sham_mainf_con
    else
        load vis_sham_mainf_con
    end
tbl = table(mat(:,1),(mat(:,2)),(mat(:,3)), -mat(:,4),mat(:,5), 'VariableNames',{'ch','obj','face','area','s'});
    lme = fitlme(tbl,'ch~ area+(1|s)','CheckHessian',true,'FitMethod','REML','DummyVarCoding','effects')
    
    anova(lme,'DFMethod','Satterthwaite')
    
    %%
    CI_c = coefCI(lme);
 
 
coef_ch = [lme.Coefficients.Estimate(2)];
CIlow=CI_c(2,1);
CIhigh = CI_c(2,2);
y = CIlow:.01:CIhigh;
x =[areas*2-.2];
b= bar(x,coef_ch,.7,'FaceColor',colours(areas,:),'EdgeColor','none','LineWidth',1.5);
b.FaceColor = 'flat';

hold on

        h = plot(areas*2-.2 + zeros(length(y)),y,'color',colours(areas,:));
  
    h(1).LineWidth = 2;


ax= gca;
ax.XTick =[];
ax.XAxis.Color = [0 0 0];
ax.YAxis.Color = 'black';
set(gca,'linewidth',1.25)
box off
%ylabel('effect on accuracy ')
ax.XTick = [1.35 3.35 5.35];
ax.XTickLabel = {'', '', ''};
set(gca,'fontsize',26)
%xlabel('coefficient') 
ylim([-.1 .05])
    
end